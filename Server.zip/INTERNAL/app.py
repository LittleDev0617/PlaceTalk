from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import sys
 
sys.path.append('../')

from naver_parser import link2lat_lon
app = Flask(__name__)
CORS(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get')
def get():
    link = request.args.get('link')    
    lat, lon = link2lat_lon(link)
    print(link, lat, lon)
    return jsonify({'lat' : lat, 'lon': lon})


app.run(host="0.0.0.0",port=1234)