import glob
import os

files = glob.glob('./마스크 그룹*.png')
for i, file in enumerate(files):
    f = open(file, 'rb').read()
    os.remove(file)
    open(f'{i}.png', 'wb').write(f)

