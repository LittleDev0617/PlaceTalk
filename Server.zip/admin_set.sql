use placetalk;
INSERT INTO tb_user VALUES(418427423, 'Admin', 'admin@admin.com');